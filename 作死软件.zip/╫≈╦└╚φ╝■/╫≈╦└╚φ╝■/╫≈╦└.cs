﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 作死软件
{
    public partial class 作死 : Form
    {
        public 作死()
        {
            InitializeComponent();
        }
    }
}
