﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 幸运数字
{
    public partial class Form1 : Form
    {
        public void Lucknum()
        {
            Random rd = new Random();
            while(true)
            {
                Form1 form1 = this;
                form1.label2.Text = Convert.ToString(rd.Next(1, 10));
            }
        }

        Thread lucknum;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lucknum = new Thread(new ThreadStart(Lucknum));
            lucknum.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lucknum.Abort();
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            关于 ab = new 关于();
            ab.Show();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
